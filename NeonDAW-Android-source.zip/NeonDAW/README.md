# Neon DAW 1.0
Independent Android music sketchpad, written in Java. Not affiliated with Image-Line.

## Features
- 12-pitch, 16-step piano roll (tap to toggle note)
- Kick, snare, hi-hat 16-step sequencer
- Four channel volume controls (melody, kick, snare, hi-hat)
- BPM 60–240
- Preview via Android AudioTrack
- Export four repetitions of the 16-step pattern as 16-bit mono WAV to Music/NeonDAW

## Build with GitHub Actions
Upload either all project files including `.github/workflows/build.yml` or upload this ZIP and copy `.github/workflows/build.yml` to the repository. In GitHub Actions choose `Build Neon DAW APK` -> `Run workflow`. Download `NeonDAW-debug-apk` artifact after a successful build.

## Limitations
This is an MVP, not a full DAW: no audio recording, timeline, project saving, MIDI import, plugins, automation, or sample import. Preview is step-based and may have timing gaps; WAV export uses deterministic synthesized samples. No third-party proprietary assets.
