package com.neondaw.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.net.Uri;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.media.*;
import java.io.*;
import java.nio.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int STEPS=16, PITCHES=12, TRACKS=4, RATE=22050;
    final boolean[][] notes=new boolean[PITCHES][STEPS];
    final boolean[][] drums=new boolean[3][STEPS];
    final float[] volumes={0.75f,0.75f,0.75f,0.75f};
    int bpm=120; boolean playing=false;
    Thread playback;
    LinearLayout root;
    TextView status;
    int bg=Color.rgb(12,14,25), neon=Color.rgb(0,236,192);
    @Override public void onCreate(Bundle b){super.onCreate(b); for(int s=0;s<16;s+=4)drums[0][s]=true; for(int s=4;s<16;s+=8)drums[1][s]=true; for(int s=0;s<16;s+=2)drums[2][s]=true; notes[0][0]=true;notes[4][4]=true;notes[7][8]=true;notes[4][12]=true;buildUI();}
    TextView label(String t,int sp){TextView v=new TextView(this);v.setText(t);v.setTextSize(sp);v.setTextColor(-1);v.setPadding(14,12,8,10);return v;}
    void buildUI(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(1);root.setPadding(14,16,14,24);root.setBackgroundColor(bg);scroll.addView(root);setContentView(scroll);
        TextView title=label("NEON DAW  •  BEAT STUDIO",23);title.setTextColor(neon);root.addView(title);
        status=label("Sẵn sàng • 4 kênh • 16 bước",13);root.addView(status);
        LinearLayout transport=new LinearLayout(this);root.addView(transport);
        Button play=new Button(this);play.setText("▶ PHÁT");transport.addView(play,new LinearLayout.LayoutParams(0,-2,1));play.setOnClickListener(v->{if(playing){stop();play.setText("▶ PHÁT");}else{start();play.setText("■ DỪNG");}});
        Button export=new Button(this);export.setText("XUẤT WAV");transport.addView(export,new LinearLayout.LayoutParams(0,-2,1));export.setOnClickListener(v->exportWav());
        TextView bpmlabel=label("BPM: "+bpm,16);root.addView(bpmlabel);
        SeekBar speed=new SeekBar(this);speed.setMax(180);speed.setProgress(bpm-60);root.addView(speed);speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean user){bpm=p+60;bpmlabel.setText("BPM: "+bpm);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        root.addView(label("PIANO ROLL • C4–B4 (chạm để đặt nốt)",16));root.addView(new GridEditor(PITCHES,notes,true),new LinearLayout.LayoutParams(-1,dp(310)));
        root.addView(label("DRUM SEQUENCER • Kick / Snare / Hat",16));root.addView(new GridEditor(3,drums,false),new LinearLayout.LayoutParams(-1,dp(130)));
        root.addView(label("MIXER • Melody / Kick / Snare / Hat",16));String[] names={"Melody","Kick","Snare","Hat"};for(int i=0;i<TRACKS;i++){final int k=i;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);root.addView(row);TextView name=label(names[i],14);row.addView(name,new LinearLayout.LayoutParams(dp(90),-2));SeekBar vol=new SeekBar(this);vol.setMax(100);vol.setProgress(Math.round(volumes[i]*100));row.addView(vol,new LinearLayout.LayoutParams(0,-2,1));vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){volumes[k]=p/100f;}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});}
        root.addView(label("WAV xuất 16-bit PCM, 22.05 kHz • 4 ô nhịp",12));
    }
    int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    class GridEditor extends View {
        int rows;boolean[][] data;boolean piano;Paint paint=new Paint(3);
        GridEditor(int rows,boolean[][] data,boolean piano){super(MainActivity.this);this.rows=rows;this.data=data;this.piano=piano;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float left=dp(36),w=(getWidth()-left)/STEPS,h=getHeight()/(float)rows;
            for(int r=0;r<rows;r++){paint.setColor(r%2==0?0xff202538:0xff171b2b);c.drawRect(0,r*h,getWidth(),(r+1)*h,paint);paint.setColor(0xffbfc8da);paint.setTextSize(dp(10));String[] drumNames={"K","S","H"};String[] keys={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};c.drawText(piano?keys[rows-1-r]:drumNames[r],dp(4),(r+0.7f)*h,paint);
                for(int s=0;s<STEPS;s++){paint.setColor(s%4==0?0xff46516b:0xff30384e);paint.setStyle(Paint.Style.STROKE);c.drawRect(left+s*w,r*h,left+(s+1)*w,(r+1)*h,paint);paint.setStyle(Paint.Style.FILL);if(data[r][s]){paint.setColor(piano?neon:0xffff6caa);c.drawRoundRect(left+s*w+2,r*h+2,left+(s+1)*w-2,(r+1)*h-2,dp(4),dp(4),paint);}}}
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;float left=dp(36);int s=(int)((e.getX()-left)/((getWidth()-left)/(float)STEPS));int r=(int)(e.getY()/(getHeight()/(float)rows));if(e.getX()>=left&&s>=0&&s<STEPS&&r>=0&&r<rows){data[r][s]=!data[r][s];invalidate();}return true;}
    }
    synchronized void stop(){playing=false;if(playback!=null)playback.interrupt();}
    void start(){if(playing)return;playing=true;playback=new Thread(()->{int index=0;while(playing&&!Thread.currentThread().isInterrupted()){int current=index;short[] pcm=renderStep(current,Math.max(1,bpm));byte[] bytes=pcmBytes(pcm);try{AudioTrack track=new AudioTrack(AudioManager.STREAM_MUSIC,RATE,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(bytes.length,AudioTrack.getMinBufferSize(RATE,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)),AudioTrack.MODE_STATIC);track.write(bytes,0,bytes.length);track.play();long millis=(long)(60000.0/bpm/4);Thread.sleep(millis);track.stop();track.release();}catch(Exception ex){runOnUiThread(()->status.setText("Lỗi phát: "+ex.getMessage()));playing=false;}index=(index+1)%STEPS;}});playback.start();}
    short[] renderStep(int step,int tempo){int len=(int)(RATE*60.0/tempo/4);short[] out=new short[len];Random rng=new Random(step+1984);for(int i=0;i<len;i++){double t=i/(double)RATE,fade=Math.exp(-t*16),mix=0;for(int r=0;r<PITCHES;r++)if(notes[r][step]){double f=261.625565*Math.pow(2,(PITCHES-1-r)/12.0);mix+=Math.sin(2*Math.PI*f*t)*0.18*volumes[0];}if(drums[0][step])mix+=Math.sin(2*Math.PI*(125-85*Math.min(t*9,1))*t)*fade*0.7*volumes[1];if(drums[1][step])mix+=(rng.nextDouble()*2-1)*Math.exp(-t*20)*0.35*volumes[2];if(drums[2][step])mix+=(rng.nextDouble()*2-1)*Math.exp(-t*65)*0.16*volumes[3];out[i]=(short)(Math.max(-1,Math.min(1,mix))*30000);}return out;}
    byte[] pcmBytes(short[] samples){byte[] b=new byte[samples.length*2];for(int i=0;i<samples.length;i++){b[2*i]=(byte)samples[i];b[2*i+1]=(byte)(samples[i]>>8);}return b;}
    void exportWav(){status.setText("Đang xuất WAV...");new Thread(()->{try{ByteArrayOutputStream pcm=new ByteArrayOutputStream();for(int bar=0;bar<4;bar++)for(int s=0;s<STEPS;s++)pcm.write(pcmBytes(renderStep(s,bpm)));byte[] audio=pcm.toByteArray();ByteArrayOutputStream file=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(file);out.writeBytes("RIFF");le32(out,36+audio.length);out.writeBytes("WAVEfmt ");le32(out,16);le16(out,1);le16(out,1);le32(out,RATE);le32(out,RATE*2);le16(out,2);le16(out,16);out.writeBytes("data");le32(out,audio.length);out.write(audio);out.flush();ContentValues values=new ContentValues();values.put(MediaStore.Audio.Media.DISPLAY_NAME,"NeonDAW_"+System.currentTimeMillis()+".wav");values.put(MediaStore.Audio.Media.MIME_TYPE,"audio/wav");values.put(MediaStore.Audio.Media.RELATIVE_PATH,Environment.DIRECTORY_MUSIC+"/NeonDAW");Uri uri=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("Cannot create file");try(OutputStream os=getContentResolver().openOutputStream(uri)){if(os==null)throw new IOException("Cannot open output");os.write(file.toByteArray());}runOnUiThread(()->status.setText("Đã xuất WAV vào Music/NeonDAW"));}catch(Exception ex){runOnUiThread(()->status.setText("Xuất WAV lỗi: "+ex.getMessage()));}}).start();}
    static void le16(DataOutputStream o,int v)throws IOException{o.writeByte(v);o.writeByte(v>>8);}
    static void le32(DataOutputStream o,int v)throws IOException{o.writeByte(v);o.writeByte(v>>8);o.writeByte(v>>16);o.writeByte(v>>24);}
    @Override protected void onDestroy(){stop();super.onDestroy();}
}
